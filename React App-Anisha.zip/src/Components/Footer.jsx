import React from 'react'

const Footer = () => {
  return (
    <div className='footer'>
        <p>Copyright © 2022  All Rights Reserved. Privacy Policy. Terms of Use.</p>
    </div>
  )
}

export default Footer